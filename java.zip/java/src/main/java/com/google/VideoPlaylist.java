package com.google;

import java.util.ArrayList;
import java.util.List;

/** A class used to represent a Playlist */
class VideoPlaylist {

	private final String title;
	private List<Video> videos;

	public VideoPlaylist(String title) {
		this.title = title;
		this.videos = new ArrayList<>();
	}

	/** Returns the title of the video. */
	String getTitle() {
		return title;
	}

	/** Returns a collection of videos in the playlist. */
	List<Video> getVideos() {
		return videos;
	}

	public void addVideo(Video Video) {
		videos.add(Video);
	}
	public void removeallVideos() {
		videos.clear();
	}
}
